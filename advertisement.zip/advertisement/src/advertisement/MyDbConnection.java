/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package advertisement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author j-sandaruwan
 */
public class MyDbConnection {

    Connection con;

    public MyDbConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Searching for connection class...");
        } catch (ClassNotFoundException cnf) {
            System.out.println("Class not found and unable to connect..." + cnf.getLocalizedMessage());
        }
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost/mysale", "root", "");

        } catch (SQLException e2) {
            e2.printStackTrace();
        }
    }
    public Connection getConnection()
    {
        return con;
    }
}
